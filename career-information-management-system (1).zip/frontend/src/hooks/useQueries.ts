import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useActor } from './useActor';
import { useInternetIdentity } from './useInternetIdentity';
import type { StudentProfile, CareerPath, UserProfile } from '../backend';
import { toast } from 'sonner';

// User Profile Queries
export function useGetCallerUserProfile() {
  const { actor, isFetching: actorFetching } = useActor();

  const query = useQuery<UserProfile | null>({
    queryKey: ['currentUserProfile'],
    queryFn: async () => {
      if (!actor) throw new Error('Actor not available');
      return actor.getCallerUserProfile();
    },
    enabled: !!actor && !actorFetching,
    retry: false,
  });

  return {
    ...query,
    isLoading: actorFetching || query.isLoading,
    isFetched: !!actor && query.isFetched,
  };
}

export function useSaveCallerUserProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: UserProfile) => {
      if (!actor) throw new Error('Actor not available');
      return actor.saveCallerUserProfile(profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['currentUserProfile'] });
      toast.success('Profile saved successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to save profile: ${error.message}`);
    },
  });
}

// Admin Check
export function useIsCallerAdmin() {
  const { actor, isFetching: actorFetching } = useActor();
  const { identity } = useInternetIdentity();

  return useQuery<boolean>({
    queryKey: ['isAdmin', identity?.getPrincipal().toString()],
    queryFn: async () => {
      if (!actor) return false;
      try {
        return await actor.isCallerAdmin();
      } catch {
        return false;
      }
    },
    enabled: !!actor && !actorFetching && !!identity,
  });
}

// Student Profile Queries
export function useGetAllStudentProfiles() {
  const { actor, isFetching } = useActor();

  return useQuery<StudentProfile[]>({
    queryKey: ['studentProfiles'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllStudentProfiles();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAddStudentProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (profile: StudentProfile) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addStudentProfile(profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['studentProfiles'] });
      toast.success('Student profile added successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to add student: ${error.message}`);
    },
  });
}

export function useUpdateStudentProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ id, profile }: { id: bigint; profile: StudentProfile }) => {
      if (!actor) throw new Error('Actor not available');
      return actor.updateStudentProfile(id, profile);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['studentProfiles'] });
      toast.success('Student profile updated successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to update student: ${error.message}`);
    },
  });
}

export function useDeleteStudentProfile() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (id: bigint) => {
      if (!actor) throw new Error('Actor not available');
      return actor.deleteStudentProfile(id);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['studentProfiles'] });
      toast.success('Student profile deleted successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to delete student: ${error.message}`);
    },
  });
}

// Career Path Queries
export function useGetAllCareerPaths() {
  const { actor, isFetching } = useActor();

  return useQuery<CareerPath[]>({
    queryKey: ['careerPaths'],
    queryFn: async () => {
      if (!actor) return [];
      return actor.getAllCareerPaths();
    },
    enabled: !!actor && !isFetching,
  });
}

export function useAddCareerPath() {
  const { actor } = useActor();
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (path: CareerPath) => {
      if (!actor) throw new Error('Actor not available');
      return actor.addCareerPath(path);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['careerPaths'] });
      toast.success('Career path added successfully');
    },
    onError: (error: Error) => {
      toast.error(`Failed to add career path: ${error.message}`);
    },
  });
}

// Search and Filter Queries
export function useSearchStudents(searchTerm: string) {
  const { actor, isFetching } = useActor();

  return useQuery<StudentProfile[]>({
    queryKey: ['searchStudents', searchTerm],
    queryFn: async () => {
      if (!actor || !searchTerm) return [];
      return actor.searchStudentsByName(searchTerm);
    },
    enabled: !!actor && !isFetching && !!searchTerm,
  });
}

export function useCombinedFilter(
  name: string | null,
  careerPath: string | null,
  degree: string | null,
  graduationYear: bigint | null
) {
  const { actor, isFetching } = useActor();

  return useQuery<StudentProfile[]>({
    queryKey: ['combinedFilter', name, careerPath, degree, graduationYear?.toString()],
    queryFn: async () => {
      if (!actor) return [];
      return actor.combinedFilter(name, careerPath, degree, graduationYear);
    },
    enabled: !!actor && !isFetching,
  });
}
