import { useState } from 'react';
import { useGetAllCareerPaths, useAddCareerPath } from '../hooks/useQueries';
import type { CareerPath } from '../backend';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { X } from 'lucide-react';

interface CareerPathManagementProps {
  showForm: boolean;
  onCloseForm: () => void;
}

export default function CareerPathManagement({ showForm, onCloseForm }: CareerPathManagementProps) {
  const { data: careerPaths = [] } = useGetAllCareerPaths();
  const addCareerPath = useAddCareerPath();

  const [formData, setFormData] = useState({
    name: '',
    description: '',
  });

  const resetForm = () => {
    setFormData({ name: '', description: '' });
    onCloseForm();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const path: CareerPath = {
      name: formData.name,
      description: formData.description,
    };

    await addCareerPath.mutateAsync(path);
    resetForm();
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Career Path Management</CardTitle>
          <CardDescription>View and manage available career paths</CardDescription>
        </CardHeader>
        <CardContent>
          {careerPaths.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No career paths added yet. Click "Add Career Path" to get started.
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {careerPaths.map((path, index) => (
                <Card key={index} className="border-2">
                  <CardHeader>
                    <CardTitle className="text-lg">{path.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{path.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showForm} onOpenChange={(open) => !open && resetForm()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add New Career Path</DialogTitle>
            <DialogDescription>Enter career path details to add to the system</DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="pathName">Career Path Name *</Label>
              <Input
                id="pathName"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Software Engineering"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="pathDescription">Description *</Label>
              <Textarea
                id="pathDescription"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe this career path..."
                rows={4}
                required
              />
            </div>
            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={resetForm}>
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
              <Button type="submit" disabled={addCareerPath.isPending}>
                {addCareerPath.isPending ? 'Adding...' : 'Add Career Path'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
