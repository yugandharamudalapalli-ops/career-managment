import { useState } from 'react';
import {
  useGetAllStudentProfiles,
  useAddStudentProfile,
  useUpdateStudentProfile,
  useDeleteStudentProfile,
  useGetAllCareerPaths,
} from '../hooks/useQueries';
import type { StudentProfile } from '../backend';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Pencil, Trash2, X } from 'lucide-react';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

interface StudentManagementProps {
  showForm: boolean;
  onCloseForm: () => void;
}

export default function StudentManagement({ showForm, onCloseForm }: StudentManagementProps) {
  const { data: students = [] } = useGetAllStudentProfiles();
  const { data: careerPaths = [] } = useGetAllCareerPaths();
  const addStudent = useAddStudentProfile();
  const updateStudent = useUpdateStudentProfile();
  const deleteStudent = useDeleteStudentProfile();

  const [editingStudent, setEditingStudent] = useState<StudentProfile | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<bigint | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    address: '',
    degree: '',
    gpa: '',
    graduationYear: '',
    careerPath: '',
    experienceLevel: '',
    skills: '',
  });

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      address: '',
      degree: '',
      gpa: '',
      graduationYear: '',
      careerPath: '',
      experienceLevel: '',
      skills: '',
    });
    setEditingStudent(null);
    onCloseForm();
  };

  const handleEdit = (student: StudentProfile) => {
    setEditingStudent(student);
    setFormData({
      name: student.name,
      email: student.contactInfo.email,
      phone: student.contactInfo.phone,
      address: student.contactInfo.address,
      degree: student.academicDetails.degree,
      gpa: student.academicDetails.gpa.toString(),
      graduationYear: student.academicDetails.graduationYear.toString(),
      careerPath: student.careerInfo.careerPath,
      experienceLevel: student.careerInfo.experienceLevel,
      skills: student.careerInfo.skills.join(', '),
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const profile: StudentProfile = {
      id: editingStudent?.id || BigInt(0),
      name: formData.name,
      contactInfo: {
        email: formData.email,
        phone: formData.phone,
        address: formData.address,
      },
      academicDetails: {
        degree: formData.degree,
        gpa: parseFloat(formData.gpa),
        graduationYear: BigInt(formData.graduationYear),
      },
      careerInfo: {
        careerPath: formData.careerPath,
        experienceLevel: formData.experienceLevel,
        skills: formData.skills.split(',').map((s) => s.trim()).filter(Boolean),
      },
    };

    if (editingStudent) {
      await updateStudent.mutateAsync({ id: editingStudent.id, profile });
    } else {
      await addStudent.mutateAsync(profile);
    }

    resetForm();
  };

  const handleDelete = async (id: bigint) => {
    await deleteStudent.mutateAsync(id);
    setDeleteConfirm(null);
  };

  const isOpen = showForm || editingStudent !== null;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Student Management</CardTitle>
          <CardDescription>View and manage all student profiles</CardDescription>
        </CardHeader>
        <CardContent>
          {students.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No students added yet. Click "Add Student" to get started.
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Degree</TableHead>
                    <TableHead>Career Path</TableHead>
                    <TableHead>GPA</TableHead>
                    <TableHead>Graduation</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {students.map((student) => (
                    <TableRow key={student.id.toString()}>
                      <TableCell className="font-medium">{student.name}</TableCell>
                      <TableCell>{student.academicDetails.degree}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">{student.careerInfo.careerPath}</Badge>
                      </TableCell>
                      <TableCell>{student.academicDetails.gpa.toFixed(2)}</TableCell>
                      <TableCell>{student.academicDetails.graduationYear.toString()}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button variant="ghost" size="icon" onClick={() => handleEdit(student)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => setDeleteConfirm(student.id)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={isOpen} onOpenChange={(open) => !open && resetForm()}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingStudent ? 'Edit Student Profile' : 'Add New Student'}</DialogTitle>
            <DialogDescription>
              {editingStudent ? 'Update student information' : 'Enter student details to create a new profile'}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <h3 className="font-semibold">Personal Information</h3>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone *</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Address *</Label>
                  <Input
                    id="address"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    required
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="font-semibold">Academic Details</h3>
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label htmlFor="degree">Degree *</Label>
                  <Input
                    id="degree"
                    value={formData.degree}
                    onChange={(e) => setFormData({ ...formData, degree: e.target.value })}
                    placeholder="e.g., Bachelor of Science"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="gpa">GPA *</Label>
                  <Input
                    id="gpa"
                    type="number"
                    step="0.01"
                    min="0"
                    max="4"
                    value={formData.gpa}
                    onChange={(e) => setFormData({ ...formData, gpa: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="graduationYear">Graduation Year *</Label>
                  <Input
                    id="graduationYear"
                    type="number"
                    min="1900"
                    max="2100"
                    value={formData.graduationYear}
                    onChange={(e) => setFormData({ ...formData, graduationYear: e.target.value })}
                    required
                  />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <h3 className="font-semibold">Career Information</h3>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="careerPath">Career Path *</Label>
                  {careerPaths.length > 0 ? (
                    <Select value={formData.careerPath} onValueChange={(value) => setFormData({ ...formData, careerPath: value })}>
                      <SelectTrigger id="careerPath">
                        <SelectValue placeholder="Select career path" />
                      </SelectTrigger>
                      <SelectContent>
                        {careerPaths.map((path, index) => (
                          <SelectItem key={index} value={path.name}>
                            {path.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  ) : (
                    <Input
                      id="careerPath"
                      value={formData.careerPath}
                      onChange={(e) => setFormData({ ...formData, careerPath: e.target.value })}
                      placeholder="e.g., Software Engineering"
                      required
                    />
                  )}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="experienceLevel">Experience Level *</Label>
                  <Select value={formData.experienceLevel} onValueChange={(value) => setFormData({ ...formData, experienceLevel: value })}>
                    <SelectTrigger id="experienceLevel">
                      <SelectValue placeholder="Select experience level" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Entry Level">Entry Level</SelectItem>
                      <SelectItem value="Junior">Junior</SelectItem>
                      <SelectItem value="Mid-Level">Mid-Level</SelectItem>
                      <SelectItem value="Senior">Senior</SelectItem>
                      <SelectItem value="Expert">Expert</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="skills">Skills (comma-separated) *</Label>
                <Input
                  id="skills"
                  value={formData.skills}
                  onChange={(e) => setFormData({ ...formData, skills: e.target.value })}
                  placeholder="e.g., JavaScript, React, Node.js"
                  required
                />
              </div>
            </div>

            <div className="flex justify-end gap-2">
              <Button type="button" variant="outline" onClick={resetForm}>
                <X className="h-4 w-4 mr-2" />
                Cancel
              </Button>
              <Button type="submit" disabled={addStudent.isPending || updateStudent.isPending}>
                {addStudent.isPending || updateStudent.isPending
                  ? 'Saving...'
                  : editingStudent
                    ? 'Update Student'
                    : 'Add Student'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteConfirm !== null} onOpenChange={(open) => !open && setDeleteConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the student profile.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteConfirm && handleDelete(deleteConfirm)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
