import { useState, useMemo } from 'react';
import { useGetAllStudentProfiles, useGetAllCareerPaths } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Search, Briefcase, GraduationCap, Mail, Phone, MapPin } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

export default function PublicCareerView() {
  const { data: students = [], isLoading: studentsLoading } = useGetAllStudentProfiles();
  const { data: careerPaths = [], isLoading: careerPathsLoading } = useGetAllCareerPaths();

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCareerPath, setSelectedCareerPath] = useState<string>('all');
  const [selectedDegree, setSelectedDegree] = useState<string>('all');
  const [selectedYear, setSelectedYear] = useState<string>('all');

  const isLoading = studentsLoading || careerPathsLoading;

  const uniqueDegrees = useMemo(() => {
    const degrees = new Set(students.map((s) => s.academicDetails.degree));
    return Array.from(degrees).sort();
  }, [students]);

  const uniqueYears = useMemo(() => {
    const years = new Set(students.map((s) => s.academicDetails.graduationYear.toString()));
    return Array.from(years).sort().reverse();
  }, [students]);

  const filteredStudents = useMemo(() => {
    return students.filter((student) => {
      const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCareer = selectedCareerPath === 'all' || student.careerInfo.careerPath === selectedCareerPath;
      const matchesDegree = selectedDegree === 'all' || student.academicDetails.degree === selectedDegree;
      const matchesYear =
        selectedYear === 'all' || student.academicDetails.graduationYear.toString() === selectedYear;

      return matchesSearch && matchesCareer && matchesDegree && matchesYear;
    });
  }, [students, searchTerm, selectedCareerPath, selectedDegree, selectedYear]);

  if (isLoading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="text-center">
          <div className="mb-4 h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto" />
          <p className="text-muted-foreground">Loading career information...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      <div className="text-center space-y-4">
        <div className="relative h-64 overflow-hidden rounded-lg mb-6">
          <img
            src="/assets/generated/career-paths-illustration.dim_400x300.png"
            alt="Career Paths"
            className="h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/60 to-transparent flex items-end justify-center pb-8">
            <div className="text-center">
              <h1 className="text-4xl font-bold mb-2">Explore Career Paths</h1>
              <p className="text-lg text-muted-foreground">
                Browse student profiles and discover career opportunities
              </p>
            </div>
          </div>
        </div>
      </div>

      {careerPaths.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Briefcase className="h-5 w-5" />
              Available Career Paths
            </CardTitle>
            <CardDescription>Explore different career opportunities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {careerPaths.map((path, index) => (
                <Card key={index} className="border-2">
                  <CardHeader>
                    <CardTitle className="text-lg">{path.name}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{path.description}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Search & Filter Students</CardTitle>
          <CardDescription>Find students by name, career path, degree, or graduation year</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="search">Search by Name</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                id="search"
                placeholder="Enter student name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="career">Career Path</Label>
              <Select value={selectedCareerPath} onValueChange={setSelectedCareerPath}>
                <SelectTrigger id="career">
                  <SelectValue placeholder="All career paths" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All career paths</SelectItem>
                  {careerPaths.map((path, index) => (
                    <SelectItem key={index} value={path.name}>
                      {path.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="degree">Degree</Label>
              <Select value={selectedDegree} onValueChange={setSelectedDegree}>
                <SelectTrigger id="degree">
                  <SelectValue placeholder="All degrees" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All degrees</SelectItem>
                  {uniqueDegrees.map((degree) => (
                    <SelectItem key={degree} value={degree}>
                      {degree}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="year">Graduation Year</Label>
              <Select value={selectedYear} onValueChange={setSelectedYear}>
                <SelectTrigger id="year">
                  <SelectValue placeholder="All years" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All years</SelectItem>
                  {uniqueYears.map((year) => (
                    <SelectItem key={year} value={year}>
                      {year}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold">
            Student Profiles {filteredStudents.length > 0 && `(${filteredStudents.length})`}
          </h2>
        </div>

        {filteredStudents.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <GraduationCap className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-lg font-medium">No students found</p>
              <p className="text-sm text-muted-foreground">Try adjusting your search filters</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredStudents.map((student) => (
              <Card key={student.id.toString()} className="overflow-hidden">
                <CardHeader className="pb-4">
                  <div className="flex items-start gap-4">
                    <Avatar className="h-16 w-16">
                      <AvatarImage src="/assets/generated/student-avatar-placeholder.dim_150x150.png" />
                      <AvatarFallback>{student.name.substring(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <CardTitle className="text-lg truncate">{student.name}</CardTitle>
                      <CardDescription className="flex items-center gap-1 mt-1">
                        <GraduationCap className="h-3 w-3" />
                        {student.academicDetails.degree}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex items-center gap-2 text-sm font-medium mb-2">
                      <Briefcase className="h-4 w-4 text-muted-foreground" />
                      Career Information
                    </div>
                    <Badge variant="secondary" className="mb-2">
                      {student.careerInfo.careerPath}
                    </Badge>
                    <p className="text-sm text-muted-foreground">
                      Experience: {student.careerInfo.experienceLevel}
                    </p>
                    {student.careerInfo.skills.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {student.careerInfo.skills.slice(0, 3).map((skill, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                        {student.careerInfo.skills.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{student.careerInfo.skills.length - 3}
                          </Badge>
                        )}
                      </div>
                    )}
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm">
                      <GraduationCap className="h-4 w-4 text-muted-foreground" />
                      <span className="text-muted-foreground">GPA:</span>
                      <span className="font-medium">{student.academicDetails.gpa.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <GraduationCap className="h-4 w-4 text-muted-foreground" />
                      <span className="text-muted-foreground">Graduation:</span>
                      <span className="font-medium">{student.academicDetails.graduationYear.toString()}</span>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Mail className="h-4 w-4" />
                      <span className="truncate">{student.contactInfo.email}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Phone className="h-4 w-4" />
                      <span>{student.contactInfo.phone}</span>
                    </div>
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <MapPin className="h-4 w-4" />
                      <span className="truncate">{student.contactInfo.address}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
