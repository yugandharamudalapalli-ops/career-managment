import { useState } from 'react';
import { useGetAllStudentProfiles, useGetAllCareerPaths } from '../hooks/useQueries';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, Briefcase, Plus } from 'lucide-react';
import StudentManagement from '../components/StudentManagement';
import CareerPathManagement from '../components/CareerPathManagement';
import { Separator } from '@/components/ui/separator';

export default function AdminDashboard() {
  const { data: students = [], isLoading: studentsLoading } = useGetAllStudentProfiles();
  const { data: careerPaths = [], isLoading: careerPathsLoading } = useGetAllCareerPaths();
  const [showStudentForm, setShowStudentForm] = useState(false);
  const [showCareerPathForm, setShowCareerPathForm] = useState(false);

  const isLoading = studentsLoading || careerPathsLoading;

  if (isLoading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <div className="text-center">
          <div className="mb-4 h-12 w-12 animate-spin rounded-full border-4 border-primary border-t-transparent mx-auto" />
          <p className="text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="relative h-48 overflow-hidden rounded-lg">
        <img
          src="/assets/generated/dashboard-header.dim_800x200.png"
          alt="Dashboard Header"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/90 to-indigo-600/90 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl font-bold mb-2">Admin Dashboard</h1>
            <p className="text-lg opacity-90">Manage students and career information</p>
          </div>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Students</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{students.length}</div>
            <p className="text-xs text-muted-foreground mt-1">Student profiles in system</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Career Paths</CardTitle>
            <Briefcase className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{careerPaths.length}</div>
            <p className="text-xs text-muted-foreground mt-1">Available career paths</p>
          </CardContent>
        </Card>
      </div>

      <div className="flex gap-4">
        <Button onClick={() => setShowStudentForm(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          Add Student
        </Button>
        <Button onClick={() => setShowCareerPathForm(true)} variant="outline" className="gap-2">
          <Plus className="h-4 w-4" />
          Add Career Path
        </Button>
      </div>

      <Separator />

      <StudentManagement showForm={showStudentForm} onCloseForm={() => setShowStudentForm(false)} />

      <Separator />

      <CareerPathManagement showForm={showCareerPathForm} onCloseForm={() => setShowCareerPathForm(false)} />
    </div>
  );
}
